TODO :

~~decouper/simplifier les fonction de lancés de dés~~
~~gestion de la Foi dans les lancés de dés~~
~~lancés de dés des objets~~
~~gestion des pouvoirs~~ (avec lancé ?)
~~gestion des effets (modificateurs de stats ?)~~
~~gestion des blessures~~

~~info-bulles sur les talents ?~~
~~separer les declencheurs clic-droit/clic-gauche~~
~~gestion des langues~~

~~jet dés des des objets pour les pnj~~
~~Ltrads ?~~
~~supprimer item-effets ?~~
~~actor-character.mjs -> getRollData ?~~
~~malus de précision des armes~~
~~cacher les competences vide des PNJs ?~~
~~correction bug jet de des NPC~~

~~items simples (hors armure et armes)~~
~~bug trad / nom de l'acteur sur le lancé de dés~~


~~modifier ecran absolu pour tenir compte de la précision~~
~~gestion des armes et armures (bonus aux RU / dégâts)~~
~~supprimer les langues~~
~~reparer les blessures~~
corriger les .5 en + a l'affichage
mettre en place une factory
moins de strings dans le templating
details des resultats relatifs