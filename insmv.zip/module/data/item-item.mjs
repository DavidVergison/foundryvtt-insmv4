import InsMvItemBase from "./base-item.mjs";

export default class InsMvItem extends InsMvItemBase {

  static defineSchema() {
    return super.defineSchema();
  }

  prepareDerivedData() {

  }
}